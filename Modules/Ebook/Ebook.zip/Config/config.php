<?php

return [
    'name' => 'Ebook'
];
