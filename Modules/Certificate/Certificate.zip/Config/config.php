<?php

return [
    'name' => __('Certificate')
];
