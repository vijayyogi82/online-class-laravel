<li class="{{ Nav::isResource('upi') }}">
    <a  class="nav-link" href="{{url('upi')}}">
    <i class="feather icon-maximize text-secondary"></i><span>{{ __('Upi') }}</span>
    </a>  
</li>