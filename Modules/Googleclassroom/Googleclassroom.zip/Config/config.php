<?php

return [
    'name' => 'Googleclassroom'
];
