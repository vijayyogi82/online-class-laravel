<!-- This will append in  sidebar for admin-->
<!-- Resume Tab start -->
<li class="{{ Nav::isResource('resume') }}">
    <a  class="nav-link" href="{{url('resume')}}">
    <i class="feather icon-book text-secondary"></i><span>{{ __('Resume') }}</span>
    </a>  
</li>
<!-- Resume tab end-->