<!--job portal tab-->
<a target="__blank" href="{{ route('job.index')}}" title="Job Portal"><li><i data-feather="briefcase"></i>{{ __('Job Portal') }}</li></a>
<!-- job portal end -->
