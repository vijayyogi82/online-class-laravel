<!-- job search  Tab start -->
<a target="__blank"href="{{route('job.find')}}" title="{{ __("Search job") }}">
    <li><i data-feather="search"></i>{{ __('Search job') }}</li>
</a>
<!-- job search  Tab end -->             