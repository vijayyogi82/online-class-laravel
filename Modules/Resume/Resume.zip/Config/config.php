<?php

return [
    'name' => __('Resume')
];
