<?php

return [
    'name' => 'Chatboard'
];
