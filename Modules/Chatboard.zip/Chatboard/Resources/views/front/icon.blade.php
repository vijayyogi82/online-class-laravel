<li class="{{ Nav::isResource('chatboard') }}">
    <a  class="nav-link" href="{{url('chatboard')}}">
    <i class="feather icon-message-circle text-secondary"></i><span>{{ __('My Chats') }}</span>
    <span class="badge badge-danger chat-badge">{{ __('New Addon') }}</span>
    </a>  
</li>